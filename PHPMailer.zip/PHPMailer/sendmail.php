<?php
require_once 'src/Exception.php';
require_once 'src/PHPMailer.php';
require_once 'src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

try {

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'yourgmail@gmail.com';
    $mail->Password = 'your_app_password';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;
    $mail->setFrom('yourgmail@gmail.com', 'My Website'); // Sender
    $mail->addAddress('test@gmail.com'); // Receiver
    $mail->isHTML(true);
    $mail->Subject = 'SMTP Test Mail';
    // $mail->addAttachment('invoice.pdf'); // Attachment Send

    // Multiple Mail Send
    // $mail->addAddress('user1@gmail.com');
    // $mail->addAddress('user2@gmail.com');

    // CC / BCC Send
    // $mail->addCC('cc@gmail.com');
    // $mail->addBCC('bcc@gmail.com');
    $mail->Body = '
        <h2>Mail Send Successfully</h2>
        <p>This is test mail from Core PHP SMTP.</p>
    ';

    $mail->send();

    echo "Mail Sent Successfully";

} catch (Exception $e) {

    echo "Mail Error: " . $mail->ErrorInfo;
}
?>